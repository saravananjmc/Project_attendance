﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminRegister
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        Label1 = New Label()
        PictureBox1 = New PictureBox()
        txtPassword = New TextBox()
        txtUsername = New TextBox()
        Password = New Label()
        Username = New Label()
        btnExit = New Button()
        btnRegister = New Button()
        Panel1.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.Gray
        Panel1.Controls.Add(Label1)
        Panel1.Location = New Point(1, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(486, 65)
        Panel1.TabIndex = 9
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Trebuchet MS", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = SystemColors.Control
        Label1.Location = New Point(119, 13)
        Label1.Name = "Label1"
        Label1.Size = New Size(262, 36)
        Label1.TabIndex = 0
        Label1.Text = "Admin Registration"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.LoginIcon__2_
        PictureBox1.Location = New Point(171, 77)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(149, 148)
        PictureBox1.TabIndex = 20
        PictureBox1.TabStop = False
        ' 
        ' txtPassword
        ' 
        txtPassword.Location = New Point(214, 304)
        txtPassword.Name = "txtPassword"
        txtPassword.Size = New Size(171, 27)
        txtPassword.TabIndex = 19
        ' 
        ' txtUsername
        ' 
        txtUsername.Location = New Point(214, 256)
        txtUsername.Name = "txtUsername"
        txtUsername.Size = New Size(171, 27)
        txtUsername.TabIndex = 18
        ' 
        ' Password
        ' 
        Password.AutoSize = True
        Password.Font = New Font("Georgia", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Password.ForeColor = SystemColors.Highlight
        Password.Location = New Point(72, 302)
        Password.Name = "Password"
        Password.Size = New Size(109, 27)
        Password.TabIndex = 17
        Password.Text = "Password"
        ' 
        ' Username
        ' 
        Username.AutoSize = True
        Username.Font = New Font("Georgia", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Username.ForeColor = SystemColors.Highlight
        Username.Location = New Point(72, 255)
        Username.Name = "Username"
        Username.Size = New Size(116, 27)
        Username.TabIndex = 16
        Username.Text = "Username"
        ' 
        ' btnExit
        ' 
        btnExit.BackColor = Color.Red
        btnExit.BackgroundImage = My.Resources.Resources.photos_2
        btnExit.Font = New Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnExit.ForeColor = SystemColors.ButtonHighlight
        btnExit.Location = New Point(54, 355)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(137, 69)
        btnExit.TabIndex = 22
        btnExit.Text = "Exit"
        btnExit.UseVisualStyleBackColor = False
        ' 
        ' btnRegister
        ' 
        btnRegister.BackColor = Color.Gray
        btnRegister.BackgroundImage = My.Resources.Resources.photos_2
        btnRegister.Font = New Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnRegister.ForeColor = SystemColors.ButtonHighlight
        btnRegister.Location = New Point(286, 355)
        btnRegister.Name = "btnRegister"
        btnRegister.Size = New Size(148, 69)
        btnRegister.TabIndex = 21
        btnRegister.Text = "Register"
        btnRegister.UseVisualStyleBackColor = False
        ' 
        ' AdminRegister
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.photos_1
        ClientSize = New Size(487, 445)
        Controls.Add(btnExit)
        Controls.Add(btnRegister)
        Controls.Add(PictureBox1)
        Controls.Add(txtPassword)
        Controls.Add(txtUsername)
        Controls.Add(Password)
        Controls.Add(Username)
        Controls.Add(Panel1)
        Name = "AdminRegister"
        Text = "AdminRegister"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents txtUsername As TextBox
    Friend WithEvents Password As Label
    Friend WithEvents Username As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents btnRegister As Button
End Class
