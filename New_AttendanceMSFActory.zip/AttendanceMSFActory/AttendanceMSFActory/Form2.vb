﻿Imports MySql.Data.MySqlClient

Public Class AdminDashboard
    Public CurrentAdminID As Integer

    Private Sub btnViewAttendance_Click(sender As Object, e As EventArgs) Handles btnViewAttendance.Click
        Dim viewAttendanceForm As New ViewAttendance()
        viewAttendanceForm.Show()
        Me.Hide()
    End Sub

    Private Sub btnAddAdmin_Click(sender As Object, e As EventArgs) Handles btnAddAdmin.Click
        Dim adminRegisterForm As New AdminRegister()
        adminRegisterForm.Show()
        Me.Hide()
    End Sub
    Private Function GetLoggedInAdminUsername() As String
        Dim username As String = ""

        Try
            Dim conn As New MySqlConnection("server=localhost;user id=root;password=;database=attendance_db")
            conn.Open()

            Dim query As String = "SELECT username FROM admins WHERE id=@adminID"
            Dim cmd As New MySqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@adminID", CurrentAdminID)

            Dim result As Object = cmd.ExecuteScalar()
            If result IsNot Nothing Then
                username = result.ToString()
            End If

            conn.Close()
        Catch ex As Exception
            MessageBox.Show("Error retrieving logged-in admin: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        Return username
    End Function

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        Try
            ' Ensure an admin is logged in before logging out
            If String.IsNullOrEmpty(LoggedInAdminUsername) Then
                MessageBox.Show("Error: No admin is currently logged in!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If

            ' Update logout time for the last login entry of this admin
            Dim query As String = "UPDATE admins SET logout_time = NOW() WHERE username = @username AND logout_time IS NULL ORDER BY login_time DESC LIMIT 1"

            Using conn As New MySqlConnection("server=localhost;user=root;password=;database=attendance_db;")
                conn.Open()
                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@username", LoggedInAdminUsername)
                    Dim rowsAffected As Integer = cmd.ExecuteNonQuery()

                    If rowsAffected > 0 Then
                        MessageBox.Show("Logout successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

                        ' Refresh the ViewAttendance DataGridView if it's open
                        Dim viewAttendanceForm As ViewAttendance = TryCast(Application.OpenForms("ViewAttendance"), ViewAttendance)
                        If viewAttendanceForm IsNot Nothing Then
                            viewAttendanceForm.LoadAdminAttendanceData()
                        End If

                        ' Clear logged-in admin variable and redirect to login form
                        LoggedInAdminUsername = ""
                        Me.Close()
                        Login.Show()
                    Else
                        MessageBox.Show("Error: No active session found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("An error occurred: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class
