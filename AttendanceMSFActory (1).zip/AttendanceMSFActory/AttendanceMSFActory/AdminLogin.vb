﻿Imports MySql.Data.MySqlClient

Public Class AdminLogin
    Dim conn As New MySqlConnection("server=localhost; user=root; password=; database=attendance_db")

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Try
            Dim conn As New MySqlConnection("server=localhost;user id=root;password=;database=attendance_db")
            conn.Open()

            Dim query As String = "SELECT id FROM admins WHERE username=@username AND password=@password"
            Dim cmd As New MySqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@username", txtusername.Text.Trim())
            cmd.Parameters.AddWithValue("@password", txtPassword.Text.Trim())

            Dim reader As MySqlDataReader = cmd.ExecuteReader()

            If reader.HasRows Then
                reader.Read()
                Dim adminID As Integer = reader("id")
                reader.Close()

                ' Update login time
                Dim updateQuery As String = "UPDATE admins SET login_time=NOW(), logout_time=NULL WHERE id=@adminID"
                Dim updateCmd As New MySqlCommand(updateQuery, conn)
                updateCmd.Parameters.AddWithValue("@adminID", adminID)
                updateCmd.ExecuteNonQuery()

                LoggedInAdminUsername = txtusername.Text
                MessageBox.Show("Logged in Successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

                ' Open Admin Dashboard
                Dim adminDash As New AdminDashboard()
                adminDash.Show()
                Me.Hide()
            Else
                MessageBox.Show("Invalid Admin Credentials!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            conn.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' Redirect to Login Form
        Dim loginForm As New Login()
        loginForm.Show()
        Me.Hide()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub
End Class
