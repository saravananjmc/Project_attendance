﻿Imports MySql.Data.MySqlClient
Module GlobalVariables
    Public LoggedInAdminUsername As String
End Module

Module Module1
    Public conn As MySqlConnection

    Public Sub ConnectDatabase()
        Try
            conn = New MySqlConnection("server=localhost;user id=root;password=;database=attendance_db")
            conn.Open()
        Catch ex As Exception
            MessageBox.Show("Database Connection Failed: " & ex.Message)
        End Try
    End Sub
End Module
