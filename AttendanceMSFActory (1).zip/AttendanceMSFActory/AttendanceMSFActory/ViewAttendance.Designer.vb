﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ViewAttendance
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As DataGridViewCellStyle = New DataGridViewCellStyle()
        Label1 = New Label()
        Panel1 = New Panel()
        btnBack = New Button()
        dgvEmployee = New DataGridView()
        dgvAdmin = New DataGridView()
        Label2 = New Label()
        Label3 = New Label()
        Panel1.SuspendLayout()
        CType(dgvEmployee, ComponentModel.ISupportInitialize).BeginInit()
        CType(dgvAdmin, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Trebuchet MS", 25.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = SystemColors.Control
        Label1.Location = New Point(47, 8)
        Label1.Name = "Label1"
        Label1.Size = New Size(899, 55)
        Label1.TabIndex = 0
        Label1.Text = " Attendance Management System (Factory)"
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = SystemColors.GrayText
        Panel1.Controls.Add(btnBack)
        Panel1.Controls.Add(Label1)
        Panel1.Location = New Point(0, 1)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(1228, 79)
        Panel1.TabIndex = 1
        ' 
        ' btnBack
        ' 
        btnBack.BackColor = Color.Red
        btnBack.Font = New Font("Trebuchet MS", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnBack.ForeColor = SystemColors.ButtonHighlight
        btnBack.Location = New Point(1092, 13)
        btnBack.Name = "btnBack"
        btnBack.Size = New Size(123, 51)
        btnBack.TabIndex = 1
        btnBack.Text = "Back"
        btnBack.UseVisualStyleBackColor = False
        ' 
        ' dgvEmployee
        ' 
        dgvEmployee.BackgroundColor = SystemColors.ButtonHighlight
        dgvEmployee.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = SystemColors.Window
        DataGridViewCellStyle1.Font = New Font("Segoe UI", 9F)
        DataGridViewCellStyle1.ForeColor = SystemColors.ControlText
        DataGridViewCellStyle1.NullValue = Nothing
        DataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = DataGridViewTriState.False
        dgvEmployee.DefaultCellStyle = DataGridViewCellStyle1
        dgvEmployee.Location = New Point(74, 129)
        dgvEmployee.Name = "dgvEmployee"
        dgvEmployee.RowHeadersWidth = 51
        dgvEmployee.Size = New Size(386, 242)
        dgvEmployee.TabIndex = 2
        ' 
        ' dgvAdmin
        ' 
        dgvAdmin.BackgroundColor = SystemColors.ButtonHighlight
        dgvAdmin.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvAdmin.Location = New Point(558, 129)
        dgvAdmin.Name = "dgvAdmin"
        dgvAdmin.RowHeadersWidth = 51
        dgvAdmin.Size = New Size(379, 252)
        dgvAdmin.TabIndex = 3
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Trebuchet MS", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.ForeColor = SystemColors.GrayText
        Label2.Location = New Point(210, 83)
        Label2.Name = "Label2"
        Label2.Size = New Size(174, 43)
        Label2.TabIndex = 4
        Label2.Text = "Employee"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Trebuchet MS", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.ForeColor = SystemColors.GrayText
        Label3.Location = New Point(670, 83)
        Label3.Name = "Label3"
        Label3.Size = New Size(120, 43)
        Label3.TabIndex = 5
        Label3.Text = "Admin"
        ' 
        ' ViewAttendance
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.photos_2
        ClientSize = New Size(972, 349)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(dgvAdmin)
        Controls.Add(dgvEmployee)
        Controls.Add(Panel1)
        Name = "ViewAttendance"
        Text = "ViewAttendance"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        CType(dgvEmployee, ComponentModel.ISupportInitialize).EndInit()
        CType(dgvAdmin, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents dgvEmployee As DataGridView
    Friend WithEvents dgvAdmin As DataGridView
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents btnBack As Button
End Class
